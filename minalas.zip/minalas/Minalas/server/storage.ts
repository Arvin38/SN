import {
  users,
  crops,
  cropRequests,
  transactions,
  conversations,
  messages,
  paymentMethods,
  type User,
  type UpsertUser,
  type Crop,
  type InsertCrop,
  type CropRequest,
  type InsertCropRequest,
  type Transaction,
  type InsertTransaction,
  type Conversation,
  type Message,
  type InsertMessage,
  type PaymentMethod,
  type InsertPaymentMethod,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, ilike, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Crop operations
  getAllCrops(): Promise<Crop[]>;
  getCropsByCategory(category: string): Promise<Crop[]>;
  searchCrops(query: string): Promise<Crop[]>;
  getCropById(id: string): Promise<Crop | undefined>;
  createCrop(crop: InsertCrop): Promise<Crop>;
  updateCropQuantity(id: string, quantity: number): Promise<Crop>;

  // Crop request operations
  getCropRequestsByUser(userId: string): Promise<CropRequest[]>;
  createCropRequest(request: InsertCropRequest): Promise<CropRequest>;

  // Transaction operations
  getTransactionsByUser(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Chat operations
  getConversationsByUser(userId: string): Promise<Conversation[]>;
  getMessagesByConversation(conversationId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  createOrGetAIConversation(userId: string): Promise<Conversation>;

  // Payment operations
  getPaymentMethodsByUser(userId: string): Promise<PaymentMethod[]>;
  createPaymentMethod(paymentMethod: InsertPaymentMethod): Promise<PaymentMethod>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Crop operations
  async getAllCrops(): Promise<Crop[]> {
    return await db
      .select()
      .from(crops)
      .orderBy(desc(crops.createdAt));
  }

  async getCropsByCategory(category: string): Promise<Crop[]> {
    return await db
      .select()
      .from(crops)
      .where(eq(crops.category, category))
      .orderBy(desc(crops.createdAt));
  }

  async searchCrops(query: string): Promise<Crop[]> {
    return await db
      .select()
      .from(crops)
      .where(ilike(crops.name, `%${query}%`))
      .orderBy(desc(crops.createdAt));
  }

  async getCropById(id: string): Promise<Crop | undefined> {
    const [crop] = await db.select().from(crops).where(eq(crops.id, id));
    return crop;
  }

  async createCrop(crop: InsertCrop): Promise<Crop> {
    const [newCrop] = await db.insert(crops).values(crop).returning();
    return newCrop;
  }

  async updateCropQuantity(id: string, quantity: number): Promise<Crop> {
    const [updatedCrop] = await db
      .update(crops)
      .set({ quantity, updatedAt: new Date() })
      .where(eq(crops.id, id))
      .returning();
    return updatedCrop;
  }

  // Crop request operations
  async getCropRequestsByUser(userId: string): Promise<CropRequest[]> {
    return await db
      .select()
      .from(cropRequests)
      .where(eq(cropRequests.requesterId, userId))
      .orderBy(desc(cropRequests.createdAt));
  }

  async createCropRequest(request: InsertCropRequest): Promise<CropRequest> {
    const [newRequest] = await db
      .insert(cropRequests)
      .values(request)
      .returning();
    return newRequest;
  }

  // Transaction operations
  async getTransactionsByUser(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.buyerId, userId),
        )
      )
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db
      .insert(transactions)
      .values(transaction)
      .returning();
    return newTransaction;
  }

  // Chat operations
  async getConversationsByUser(userId: string): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .where(eq(conversations.participantIds, [userId]))
      .orderBy(desc(conversations.updatedAt));
  }

  async getMessagesByConversation(conversationId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async createOrGetAIConversation(userId: string): Promise<Conversation> {
    // Check if AI conversation already exists
    const [existingConv] = await db
      .select()
      .from(conversations)
      .where(
        and(
          eq(conversations.type, "ai"),
          eq(conversations.participantIds, [userId])
        )
      );

    if (existingConv) {
      return existingConv;
    }

    // Create new AI conversation
    const [newConv] = await db
      .insert(conversations)
      .values({
        participantIds: [userId],
        type: "ai",
      })
      .returning();

    return newConv;
  }

  // Payment operations
  async getPaymentMethodsByUser(userId: string): Promise<PaymentMethod[]> {
    return await db
      .select()
      .from(paymentMethods)
      .where(eq(paymentMethods.userId, userId))
      .orderBy(desc(paymentMethods.createdAt));
  }

  async createPaymentMethod(paymentMethod: InsertPaymentMethod): Promise<PaymentMethod> {
    const [newPaymentMethod] = await db
      .insert(paymentMethods)
      .values(paymentMethod)
      .returning();
    return newPaymentMethod;
  }
}

export const storage = new DatabaseStorage();
