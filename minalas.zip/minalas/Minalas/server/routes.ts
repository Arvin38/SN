import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./oidcAuth"; // ✅ renamed
import { getCropInformation } from "./aiService";
import { 
  insertCropSchema, 
  insertCropRequestSchema, 
  insertTransactionSchema, 
  insertMessageSchema, 
  insertPaymentMethodSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Crop routes
  app.get("/api/crops", async (req, res) => {
    try {
      const { category, search } = req.query;
      let crops;

      if (search) {
        crops = await storage.searchCrops(search as string);
      } else if (category && category !== "all") {
        crops = await storage.getCropsByCategory(category as string);
      } else {
        crops = await storage.getAllCrops();
      }

      res.json(crops);
    } catch (error) {
      console.error("Error fetching crops:", error);
      res.status(500).json({ message: "Failed to fetch crops" });
    }
  });

  app.get("/api/crops/:id", async (req, res) => {
    try {
      const crop = await storage.getCropById(req.params.id);
      if (!crop) {
        return res.status(404).json({ message: "Crop not found" });
      }
      res.json(crop);
    } catch (error) {
      console.error("Error fetching crop:", error);
      res.status(500).json({ message: "Failed to fetch crop" });
    }
  });

  app.post("/api/crops", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cropData = insertCropSchema.parse({
        ...req.body,
        farmerId: userId,
      });

      const crop = await storage.createCrop(cropData);
      res.status(201).json(crop);
    } catch (error) {
      console.error("Error creating crop:", error);
      res.status(400).json({ message: "Failed to create crop" });
    }
  });

  // Crop request routes
  app.get("/api/requests", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requests = await storage.getCropRequestsByUser(userId);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching requests:", error);
      res.status(500).json({ message: "Failed to fetch requests" });
    }
  });

  app.post("/api/requests", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requestData = insertCropRequestSchema.parse({
        ...req.body,
        requesterId: userId,
      });

      const request = await storage.createCropRequest(requestData);
      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating request:", error);
      res.status(400).json({ message: "Failed to create request" });
    }
  });

  // Transaction routes
  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getTransactionsByUser(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactionData = insertTransactionSchema.parse({
        ...req.body,
        buyerId: userId,
      });

      const transaction = await storage.createTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      console.error("Error creating transaction:", error);
      res.status(400).json({ message: "Failed to create transaction" });
    }
  });

  // Chat routes
  app.get("/api/chat/ai", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversation = await storage.createOrGetAIConversation(userId);
      const messages = await storage.getMessagesByConversation(conversation.id);

      res.json({
        conversation,
        messages,
      });
    } catch (error) {
      console.error("Error fetching AI chat:", error);
      res.status(500).json({ message: "Failed to fetch chat" });
    }
  });

  app.post("/api/chat/ai/message", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { message } = req.body;

      if (!message?.trim()) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get AI conversation
      const conversation = await storage.createOrGetAIConversation(userId);

      // Save user message
      await storage.createMessage({
        conversationId: conversation.id,
        senderId: userId,
        senderType: "user",
        content: message,
      });

      // Get available crops for context
      const availableCrops = await storage.getAllCrops();

      // Generate AI response
      const aiResponse = await getCropInformation(message, availableCrops);

      // Save AI message
      const aiMessage = await storage.createMessage({
        conversationId: conversation.id,
        senderId: null,
        senderType: "ai",
        content: aiResponse,
      });

      res.json(aiMessage);
    } catch (error) {
      console.error("Error processing AI message:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Payment method routes
  app.get("/api/payment-methods", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const paymentMethods = await storage.getPaymentMethodsByUser(userId);
      res.json(paymentMethods);
    } catch (error) {
      console.error("Error fetching payment methods:", error);
      res.status(500).json({ message: "Failed to fetch payment methods" });
    }
  });

  app.post("/api/payment-methods", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const paymentMethodData = insertPaymentMethodSchema.parse({
        ...req.body,
        userId,
      });

      const paymentMethod = await storage.createPaymentMethod(paymentMethodData);
      res.status(201).json(paymentMethod);
    } catch (error) {
      console.error("Error creating payment method:", error);
      res.status(400).json({ message: "Failed to create payment method" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
