import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "sk-test-key"
});

export interface CropInfo {
  name: string;
  price: string;
  availability: string;
  location: string;
  season: string;
  benefits: string;
}

export async function getCropInformation(query: string, availableCrops: any[]): Promise<string> {
  try {
    const cropsContext = availableCrops.map(crop => ({
      name: crop.name,
      price: `₱${crop.price} per ${crop.unit}`,
      quantity: crop.quantity,
      location: crop.location,
      category: crop.category,
      organic: crop.isOrganic
    }));

    const prompt = `You are SakaNect AI Assistant, an expert in Philippine agriculture and crop trading. 
    
Current available crops in the marketplace:
${JSON.stringify(cropsContext, null, 2)}

User query: "${query}"

Please provide a helpful response about crops, pricing, availability, farming tips, or marketplace guidance. 
Be specific and reference actual crops from the marketplace when relevant. 
If asked about prices, use the actual prices from the data.
If asked about availability, refer to the current stock levels.
Keep responses conversational and helpful for both farmers and buyers.
Respond in a friendly, informative tone.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are SakaNect AI Assistant, helping users with agricultural marketplace questions in the Philippines. Be helpful, accurate, and reference real data when available."
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      max_tokens: 300,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process that request. Please try asking about crop prices, availability, or farming tips.";
  } catch (error) {
    console.error("AI service error:", error);
    return "I'm having trouble connecting right now. Please try again later or browse our available crops directly.";
  }
}

export async function generateCropRecommendations(userPreferences: {
  location?: string;
  budget?: string;
  cropType?: string;
}): Promise<string> {
  try {
    const prompt = `As an agricultural expert in the Philippines, recommend crops based on these preferences:
    Location: ${userPreferences.location || 'Not specified'}
    Budget: ${userPreferences.budget || 'Not specified'}  
    Crop Type: ${userPreferences.cropType || 'Any'}
    
    Provide practical recommendations considering Philippine climate, seasons, and market demands.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an agricultural expert specializing in Philippine farming and crop recommendations."
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      max_tokens: 250,
    });

    return response.choices[0].message.content || "I recommend checking our available crops for the best current options.";
  } catch (error) {
    console.error("AI recommendation error:", error);
    return "I'm unable to generate recommendations right now. Please browse our crop categories for available options.";
  }
}
