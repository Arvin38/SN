import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import type { Crop } from "@shared/schema";

interface CropCardProps {
  crop: Crop;
}

export default function CropCard({ crop }: CropCardProps) {
  const [isRequesting, setIsRequesting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const requestMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/requests", {
        cropName: crop.name,
        quantity: "To be specified",
        budget: "To be negotiated",
        notes: `Interested in ${crop.name} from ${crop.location}`,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Request Submitted",
        description: `Your request for ${crop.name} has been submitted successfully!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      setIsRequesting(false);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit request. Please try again.",
        variant: "destructive",
      });
      setIsRequesting(false);
    },
  });

  const handleRequest = () => {
    setIsRequesting(true);
    requestMutation.mutate();
  };

  const getCropImage = (cropName: string, category: string) => {
    // Use Unsplash images based on crop type
    const searchTerm = cropName.toLowerCase().replace(/\s+/g, '-');
    return `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300&q=80`;
  };

  const getAvailabilityStatus = () => {
    if (crop.quantity === 0) {
      return { status: "Sold", color: "bg-gray-500 text-white", disabled: true };
    }
    return { status: "Available", color: "bg-primary text-primary-foreground", disabled: false };
  };

  const availability = getAvailabilityStatus();

  return (
    <Card 
      className="overflow-hidden shadow-sm border border-border"
      data-testid={`crop-card-${crop.id}`}
    >
      <img 
        src={crop.imageUrl || getCropImage(crop.name, crop.category)}
        alt={crop.name}
        className="w-full h-48 object-cover"
        data-testid={`crop-image-${crop.id}`}
      />
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-2" data-testid={`crop-name-${crop.id}`}>
          {crop.name}
        </h3>
        <div className="text-2xl font-bold text-primary mb-2" data-testid={`crop-price-${crop.id}`}>
          ₱{parseFloat(crop.price).toFixed(2)} per {crop.unit}
        </div>
        <div className="text-sm text-muted-foreground mb-2" data-testid={`crop-quantity-${crop.id}`}>
          Quantity: {crop.quantity} {crop.unit}s available
        </div>
        <div className="text-sm text-muted-foreground mb-4" data-testid={`crop-location-${crop.id}`}>
          Location: {crop.location}
        </div>
        {crop.description && (
          <div className="text-sm text-muted-foreground mb-4" data-testid={`crop-description-${crop.id}`}>
            {crop.description}
          </div>
        )}
        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            <Badge className={availability.color} data-testid={`crop-status-${crop.id}`}>
              {availability.status}
            </Badge>
            {crop.isOrganic && (
              <Badge className="bg-green-100 text-green-800" data-testid={`crop-organic-${crop.id}`}>
                Organic
              </Badge>
            )}
            <Badge className="bg-secondary text-primary" data-testid={`crop-fresh-${crop.id}`}>
              Fresh
            </Badge>
          </div>
          {availability.disabled ? (
            <Button 
              disabled 
              className="bg-gray-300 text-gray-500 cursor-not-allowed"
              data-testid={`crop-button-disabled-${crop.id}`}
            >
              Sold out
            </Button>
          ) : (
            <Button 
              onClick={handleRequest}
              disabled={isRequesting || requestMutation.isPending}
              className="bg-primary text-primary-foreground hover:opacity-90"
              data-testid={`crop-button-request-${crop.id}`}
            >
              {isRequesting || requestMutation.isPending ? "Requesting..." : "Request"}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
