import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Sprout, 
  Home, 
  ClipboardList, 
  DollarSign, 
  MessageCircle, 
  Plus,
  CreditCard,
  BarChart3,
  User,
  ChevronDown
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface LayoutProps {
  children: ReactNode;
}

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Crops", href: "/crops", icon: Sprout },
  { name: "Requests", href: "/requests", icon: ClipboardList },
  { name: "Transactions", href: "/transactions", icon: DollarSign },
  { name: "Chat", href: "/chat", icon: MessageCircle },
  { name: "Crop Listing", href: "/crop-listing", icon: Plus },
  { name: "Payments", href: "/payments", icon: CreditCard },
  { name: "Reports", href: "/reports", icon: BarChart3 },
];

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getDisplayName = () => {
    if ((user as any)?.firstName && (user as any)?.lastName) {
      return `${(user as any).firstName} ${(user as any).lastName}`;
    }
    if ((user as any)?.firstName) {
      return (user as any).firstName;
    }
    if ((user as any)?.email) {
      return (user as any).email.split('@')[0];
    }
    return "User";
  };

  return (
    <div className="min-h-screen bg-background" data-testid="main-layout">
      {/* Navigation Header */}
      <header className="bg-card border-b border-border" data-testid="main-header">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center" data-testid="header-logo">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mr-2">
              <Sprout className="text-white text-sm" />
            </div>
            <span className="text-xl font-bold text-primary">SakaNect</span>
            <span className="ml-4 text-muted-foreground">Hi {getDisplayName()}!</span>
          </div>
          
          {/* Profile */}
          <div className="flex items-center" data-testid="header-profile">
            <Button variant="ghost" onClick={handleLogout} className="flex items-center">
              <User className="text-muted-foreground mr-2 h-4 w-4" />
              <span className="text-sm font-medium">Profile</span>
              <ChevronDown className="ml-2 h-4 w-4 text-muted-foreground" />
            </Button>
          </div>
        </div>
        
        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-6">
          <nav className="flex space-x-8" data-testid="main-navigation">
            {navigation.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;
              
              return (
                <Link key={item.name} href={item.href}>
                  <Button
                    variant="ghost"
                    className={`py-4 px-2 border-b-2 transition-colors ${
                      isActive
                        ? "border-primary text-primary font-medium"
                        : "border-transparent text-muted-foreground hover:text-foreground"
                    }`}
                    data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Icon className="mr-2 h-4 w-4" />
                    {item.name}
                  </Button>
                </Link>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main data-testid="main-content">
        {children}
      </main>
    </div>
  );
}
