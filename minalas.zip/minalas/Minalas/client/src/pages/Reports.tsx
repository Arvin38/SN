import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, ShoppingCart, Sprout, ClipboardList, BarChart3, PieChart, Download, FileSpreadsheet } from "lucide-react";

export default function Reports() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-8" data-testid="reports-page">
      <h1 className="text-3xl font-bold mb-8" data-testid="page-title">Reports & Analytics</h1>
      
      {/* Report Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" data-testid="report-cards">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Total Sales</h3>
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
            <div className="text-2xl font-bold" data-testid="stat-total-sales">₱0.00</div>
            <div className="text-sm text-green-500">+0% from last month</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Orders</h3>
              <ShoppingCart className="h-5 w-5 text-blue-500" />
            </div>
            <div className="text-2xl font-bold" data-testid="stat-orders">0</div>
            <div className="text-sm text-blue-500">+0% from last month</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Crops Listed</h3>
              <Sprout className="h-5 w-5 text-orange-500" />
            </div>
            <div className="text-2xl font-bold" data-testid="stat-crops-listed">0</div>
            <div className="text-sm text-orange-500">Active listings</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Requests</h3>
              <ClipboardList className="h-5 w-5 text-purple-500" />
            </div>
            <div className="text-2xl font-bold" data-testid="stat-requests">0</div>
            <div className="text-sm text-purple-500">Total received</div>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8" data-testid="charts-section">
        {/* Sales Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Sales Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center text-muted-foreground" data-testid="sales-chart-placeholder">
              <div className="text-center">
                <BarChart3 className="mx-auto h-12 w-12 mb-2" />
                <p>Sales chart will appear here</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Top Crops */}
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Crops</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center text-muted-foreground" data-testid="top-crops-chart-placeholder">
              <div className="text-center">
                <PieChart className="mx-auto h-12 w-12 mb-2" />
                <p>Top crops chart will appear here</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Export Options */}
      <Card data-testid="export-options-card">
        <CardHeader>
          <CardTitle>Export Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <Button className="bg-primary text-primary-foreground" data-testid="button-download-pdf">
              <Download className="mr-2 h-4 w-4" />
              Download PDF
            </Button>
            <Button variant="outline" data-testid="button-export-excel">
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Export to Excel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
