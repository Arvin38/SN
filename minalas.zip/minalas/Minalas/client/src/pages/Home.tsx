import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingBasket, ClipboardCheck, Shield } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen" data-testid="home-page">
      {/* Hero Banner */}
      <div className="hero-bg text-white py-16" data-testid="hero-section">
        <div className="max-w-7xl mx-auto px-6">
          <h1 className="text-4xl font-bold mb-4" data-testid="hero-title">Welcome to SakaNect</h1>
          <p className="text-xl mb-6" data-testid="hero-description">Connecting farmers and buyers for fresh agricultural produce</p>
          <Link href="/crops">
            <Button 
              className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-medium hover:opacity-90 transition-opacity"
              data-testid="button-browse-crops"
            >
              Browse Available Crops
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Feature Cards */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Browse Marketplace */}
          <Card className="shadow-sm border border-border" data-testid="card-browse-marketplace">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mb-4">
                <ShoppingBasket className="text-primary text-xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Browse Marketplace</h3>
              <p className="text-muted-foreground mb-4">Discover fresh produce from local farmers with detailed information about quality and availability.</p>
              <Link href="/crops">
                <Button variant="link" className="text-primary hover:underline font-medium p-0" data-testid="link-browse-now">
                  Browse Now →
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* Request Crops */}
          <Card className="shadow-sm border border-border" data-testid="card-request-crops">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mb-4">
                <ClipboardCheck className="text-primary text-xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Request Crops</h3>
              <p className="text-muted-foreground mb-4">Can't find what you need? Submit a request and let farmers know what you're looking for.</p>
              <Link href="/requests">
                <Button variant="link" className="text-primary hover:underline font-medium p-0" data-testid="link-make-request">
                  Make Request →
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* Secure Transactions */}
          <Card className="shadow-sm border border-border" data-testid="card-secure-transactions">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mb-4">
                <Shield className="text-primary text-xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Secure Transactions</h3>
              <p className="text-muted-foreground mb-4">Trade safely with our secure transaction system that protects both buyers and farmers.</p>
              <Link href="/transactions">
                <Button variant="link" className="text-primary hover:underline font-medium p-0" data-testid="link-learn-more">
                  Learn More →
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
        
        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6" data-testid="statistics-section">
          <Card className="text-center border border-border">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2" data-testid="stat-farmers">150+</div>
              <div className="text-muted-foreground">Active Farmers</div>
            </CardContent>
          </Card>
          <Card className="text-center border border-border">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2" data-testid="stat-crops">500+</div>
              <div className="text-muted-foreground">Available Crops</div>
            </CardContent>
          </Card>
          <Card className="text-center border border-border">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2" data-testid="stat-trades">1,200+</div>
              <div className="text-muted-foreground">Successful Trades</div>
            </CardContent>
          </Card>
          <Card className="text-center border border-border">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2" data-testid="stat-satisfaction">95%</div>
              <div className="text-muted-foreground">Satisfaction Rate</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
