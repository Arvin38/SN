import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { CloudUpload, ArrowLeft, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { insertCropSchema } from "@shared/schema";
import { Link, useLocation } from "wouter";
import { z } from "zod";

const cropFormSchema = insertCropSchema.extend({
  price: z.string().min(1, "Price is required"),
});

type CropFormData = z.infer<typeof cropFormSchema>;

export default function CropListing() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CropFormData>({
    resolver: zodResolver(cropFormSchema),
    defaultValues: {
      name: "",
      category: "",
      description: "",
      price: "",
      unit: "",
      quantity: 0,
      location: "",
      isOrganic: false,
    },
  });

  const createCropMutation = useMutation({
    mutationFn: async (data: CropFormData) => {
      const response = await apiRequest("POST", "/api/crops", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Crop listing created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/crops"] });
      setLocation("/crops");
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create crop listing. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CropFormData) => {
    createCropMutation.mutate(data);
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8" data-testid="crop-listing-page">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold" data-testid="page-title">Add New Crop</h1>
        <Link href="/crops">
          <Button variant="outline" data-testid="button-back-to-crops">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Crops
          </Button>
        </Link>
      </div>
      
      <Card data-testid="crop-listing-form-card">
        <CardHeader>
          <CardTitle>Crop Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Crop Name *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Tomatoes" 
                          {...field} 
                          data-testid="input-crop-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-category">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="vegetables">Vegetables</SelectItem>
                          <SelectItem value="fruits">Fruits</SelectItem>
                          <SelectItem value="grains">Grains</SelectItem>
                          <SelectItem value="herbs">Herbs</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price per Unit *</FormLabel>
                      <FormControl>
                        <div className="flex">
                          <span className="px-3 py-2 bg-muted border border-border rounded-l-lg">₱</span>
                          <Input 
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                            className="rounded-l-none"
                            data-testid="input-price"
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="unit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Unit Type *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-unit">
                            <SelectValue placeholder="Select unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="kilo">Per Kilo</SelectItem>
                          <SelectItem value="piece">Per Piece</SelectItem>
                          <SelectItem value="bundle">Per Bundle</SelectItem>
                          <SelectItem value="sack">Per Sack</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Available Quantity *</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="0"
                          {...field}
                          onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                          data-testid="input-quantity"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Cebu City, Cebu" 
                          {...field} 
                          data-testid="input-location"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe your crop quality, farming methods, etc."
                        className="h-24"
                        {...field}
                        value={field.value || ""}
                        data-testid="textarea-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div data-testid="image-upload-section">
                <label className="block text-sm font-medium mb-2">Crop Images</label>
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                  <CloudUpload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-2">Click to upload images or drag and drop</p>
                  <p className="text-sm text-muted-foreground">PNG, JPG up to 10MB each</p>
                  <input 
                    type="file" 
                    multiple 
                    accept="image/*" 
                    className="hidden" 
                    id="cropImages" 
                    data-testid="input-crop-images"
                  />
                  <Button 
                    type="button" 
                    onClick={() => document.getElementById('cropImages')?.click()} 
                    className="mt-4"
                    variant="outline"
                    data-testid="button-choose-files"
                  >
                    Choose Files
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <FormField
                  control={form.control}
                  name="isOrganic"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox 
                          checked={field.value || false}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-organic"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Organic Certified</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
                
                <div className="flex space-x-4">
                  <Link href="/crops">
                    <Button variant="outline" data-testid="button-cancel">
                      Cancel
                    </Button>
                  </Link>
                  <Button 
                    type="submit" 
                    disabled={createCropMutation.isPending}
                    data-testid="button-add-crop"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    {createCropMutation.isPending ? "Adding..." : "Add Crop"}
                  </Button>
                </div>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
