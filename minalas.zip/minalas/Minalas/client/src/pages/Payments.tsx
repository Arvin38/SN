import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wallet, Clock, CreditCard, Plus, Receipt } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import PaymentModal from "@/components/PaymentModal";
import type { PaymentMethod } from "@shared/schema";

export default function Payments() {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const { toast } = useToast();

  const { data: paymentMethods = [], isLoading, error } = useQuery<PaymentMethod[]>({
    queryKey: ["/api/payment-methods"],
  });

  if (error) {
    if (isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return null;
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-8" data-testid="payments-page">
      <h1 className="text-3xl font-bold mb-8" data-testid="page-title">Payments</h1>
      
      {/* Payment Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8" data-testid="payment-overview">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Total Earnings</h3>
              <Wallet className="h-5 w-5 text-primary" />
            </div>
            <div className="text-2xl font-bold text-primary" data-testid="text-earnings">₱0.00</div>
            <div className="text-sm text-muted-foreground">This month</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Pending Payments</h3>
              <Clock className="h-5 w-5 text-orange-500" />
            </div>
            <div className="text-2xl font-bold text-orange-500" data-testid="text-pending">₱0.00</div>
            <div className="text-sm text-muted-foreground">Awaiting processing</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Payment Methods</h3>
              <CreditCard className="h-5 w-5 text-blue-500" />
            </div>
            <div className="text-2xl font-bold" data-testid="text-payment-methods-count">
              {paymentMethods.length}
            </div>
            <div className="text-sm text-muted-foreground">Connected accounts</div>
          </CardContent>
        </Card>
      </div>
      
      {/* Payment Methods */}
      <Card className="mb-8" data-testid="payment-methods-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Payment Methods</CardTitle>
            <Button 
              onClick={() => setShowPaymentModal(true)}
              size="sm"
              data-testid="button-add-payment-method"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Method
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4" data-testid="payment-methods-loading">
              {Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="animate-pulse flex items-center p-4 border border-border rounded-lg">
                  <div className="w-8 h-8 bg-muted rounded mr-4"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-muted rounded w-1/3 mb-2"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : paymentMethods.length === 0 ? (
            <div className="text-center py-8" data-testid="payment-methods-empty">
              <CreditCard className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No payment methods added yet</p>
              <Button 
                variant="link" 
                onClick={() => setShowPaymentModal(true)}
                className="text-primary hover:underline mt-2"
                data-testid="button-add-first-payment-method"
              >
                Add your first payment method
              </Button>
            </div>
          ) : (
            <div className="space-y-4" data-testid="payment-methods-list">
              {paymentMethods.map((method) => (
                <div 
                  key={method.id} 
                  className="flex items-center p-4 border border-border rounded-lg"
                  data-testid={`payment-method-${method.id}`}
                >
                  <div className="w-8 h-8 bg-primary rounded flex items-center justify-center mr-4">
                    <CreditCard className="h-4 w-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium" data-testid={`payment-method-name-${method.id}`}>
                      {method.accountName}
                    </div>
                    <div className="text-sm text-muted-foreground" data-testid={`payment-method-type-${method.id}`}>
                      {method.type.toUpperCase()} - ***{method.accountNumber.slice(-4)}
                    </div>
                  </div>
                  {method.isDefault && (
                    <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded" data-testid={`payment-method-default-${method.id}`}>
                      Default
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Transaction History */}
      <Card data-testid="transaction-history-card">
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8" data-testid="transaction-history-empty">
            <Receipt className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No payment transactions yet</p>
          </div>
        </CardContent>
      </Card>

      <PaymentModal 
        open={showPaymentModal}
        onOpenChange={setShowPaymentModal}
      />
    </div>
  );
}
