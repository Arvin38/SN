import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import CropCard from "@/components/CropCard";
import type { Crop } from "@shared/schema";

export default function Crops() {
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("all");

  const { data: crops = [], isLoading, error } = useQuery<Crop[]>({
    queryKey: ["/api/crops", { category: category === "all" ? undefined : category, search: searchTerm || undefined }],
    queryFn: async ({ queryKey }) => {
      const [url, params] = queryKey as [string, { category?: string; search?: string }];
      const searchParams = new URLSearchParams();
      if (params?.category) searchParams.set('category', params.category);
      if (params?.search) searchParams.set('search', params.search);
      
      const response = await fetch(`${url}?${searchParams.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch crops');
      return response.json();
    },
  });

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-8" data-testid="crops-error">
        <div className="text-center py-16">
          <p className="text-red-500">Failed to load crops. Please try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-8" data-testid="crops-page">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold" data-testid="page-title">Available Crops</h1>
        
        {/* Search and Filter */}
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search crops..." 
              className="pl-10 pr-4 py-2 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-crop-search"
            />
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-40" data-testid="select-crop-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="vegetables">Vegetables</SelectItem>
              <SelectItem value="fruits">Fruits</SelectItem>
              <SelectItem value="grains">Grains</SelectItem>
              <SelectItem value="herbs">Herbs</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Crops Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="crops-loading">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-card rounded-xl overflow-hidden shadow-sm border border-border animate-pulse">
              <div className="w-full h-48 bg-muted"></div>
              <div className="p-6 space-y-3">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
                <div className="h-4 bg-muted rounded w-2/3"></div>
              </div>
            </div>
          ))}
        </div>
      ) : crops.length === 0 ? (
        <div className="text-center py-16" data-testid="crops-empty">
          <p className="text-muted-foreground">No crops found matching your criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="crops-grid">
          {crops.map((crop) => (
            <CropCard key={crop.id} crop={crop} />
          ))}
        </div>
      )}
    </div>
  );
}
