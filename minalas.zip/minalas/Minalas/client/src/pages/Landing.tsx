import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Sprout, Wheat, Handshake, MapPin } from "lucide-react";

export default function Landing() {
  const [showSignInModal, setShowSignInModal] = useState(false);

  const handleSignIn = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background" data-testid="landing-page">
      <div className="text-center py-16">
        {/* Logo */}
        <div className="flex items-center justify-center mb-8" data-testid="logo-section">
          <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mr-2">
            <Sprout className="text-white text-xl" />
          </div>
        </div>
        
        {/* Title */}
        <h1 className="text-5xl font-bold text-primary mb-4" data-testid="main-title">SakaNect</h1>
        <p className="text-muted-foreground text-lg mb-16" data-testid="subtitle">Connect farmers and buyers across the Philippines</p>
        
        {/* Feature Cards */}
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {/* Fresh Produce */}
          <Card className="p-8 shadow-lg" data-testid="card-fresh-produce">
            <div className="w-16 h-16 bg-orange-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Wheat className="text-white text-2xl" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Fresh Produce</h3>
            <p className="text-muted-foreground">Direct from local farmers to your table</p>
          </Card>
          
          {/* Fair Trade */}
          <Card className="p-8 shadow-lg" data-testid="card-fair-trade">
            <div className="w-16 h-16 bg-orange-600 rounded-xl flex items-center justify-center mx-auto mb-6">
              <Handshake className="text-white text-2xl" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Fair Trade</h3>
            <p className="text-muted-foreground">Connect directly and trade fairly</p>
          </Card>
          
          {/* Local Network */}
          <Card className="p-8 shadow-lg" data-testid="card-local-network">
            <div className="w-16 h-16 bg-pink-500 rounded-xl flex items-center justify-center mx-auto mb-6">
              <MapPin className="text-white text-2xl" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Local Network</h3>
            <p className="text-muted-foreground">Find suppliers and buyers in your area</p>
          </Card>
        </div>
        
        {/* Sign Up Button */}
        <Button 
          onClick={() => setShowSignInModal(true)} 
          className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-medium hover:opacity-90 transition-opacity mb-6"
          data-testid="button-signup"
        >
          Sign up
        </Button>
        
        {/* Sign In Link */}
        <div className="text-muted-foreground" data-testid="signin-link-section">
          Already have an account? 
          <button 
            onClick={() => setShowSignInModal(true)} 
            className="text-primary hover:underline ml-1"
            data-testid="button-signin-link"
          >
            Sign In
          </button>
        </div>
      </div>

      {/* Sign In Modal */}
      <Dialog open={showSignInModal} onOpenChange={setShowSignInModal}>
        <DialogContent className="max-w-md" data-testid="signin-modal">
          <DialogHeader>
            <div className="flex items-center justify-center mb-6">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-2">
                <Sprout className="text-white" />
              </div>
            </div>
            <DialogTitle className="text-2xl font-bold text-center text-primary mb-2">SakaNect</DialogTitle>
            <h3 className="text-xl font-semibold text-center mb-6">Welcome Back</h3>
          </DialogHeader>
          
          {/* Social Login Buttons */}
          <Button 
            onClick={handleSignIn}
            className="w-full bg-red-500 text-white py-3 rounded-lg mb-3 flex items-center justify-center"
            data-testid="button-google-signin"
          >
            <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Continue with Google
          </Button>
          
          <Button 
            onClick={handleSignIn}
            className="w-full bg-blue-600 text-white py-3 rounded-lg mb-6 flex items-center justify-center"
            data-testid="button-facebook-signin"
          >
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            Continue with Facebook
          </Button>
          
          <div className="text-center text-muted-foreground mb-6">Or continue with email</div>
          
          {/* Email Form */}
          <form onSubmit={(e) => { e.preventDefault(); handleSignIn(); }}>
            <div className="mb-4">
              <Label className="block text-sm font-medium mb-2">Email</Label>
              <Input 
                type="email" 
                placeholder="Enter your email" 
                required 
                data-testid="input-email"
              />
            </div>
            
            <div className="mb-4">
              <Label className="block text-sm font-medium mb-2">Password</Label>
              <Input 
                type="password" 
                placeholder="Enter your password" 
                required 
                data-testid="input-password"
              />
            </div>
            
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <Checkbox id="remember" data-testid="checkbox-remember" />
                <Label htmlFor="remember" className="text-sm">Remember me</Label>
              </div>
              <Button 
                variant="link" 
                type="button" 
                className="text-sm text-primary hover:underline p-0"
                data-testid="button-forgot-password"
              >
                Forgot password?
              </Button>
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-medium hover:opacity-90 transition-opacity"
              data-testid="button-signin-submit"
            >
              Sign In
            </Button>
          </form>
          
          <Separator className="my-6" />
          
          <div className="text-center text-sm text-muted-foreground">
            Don't have an account? 
            <Button 
              variant="link" 
              onClick={handleSignIn}
              className="text-primary hover:underline p-0 ml-1"
              data-testid="button-signup-link"
            >
              Sign up
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
