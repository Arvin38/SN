import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Transaction } from "@shared/schema";

export default function Transactions() {
  const [activeTab, setActiveTab] = useState("sales");
  const { toast } = useToast();

  const { data: transactions = [], isLoading, error } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  if (error) {
    if (isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return null;
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatAmount = (amount: string) => {
    return `₱${parseFloat(amount).toFixed(2)}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const filterTransactionsByType = (type: string) => {
    return transactions.filter(transaction => transaction.type === type);
  };

  const renderTransactionsList = (filteredTransactions: Transaction[]) => {
    if (isLoading) {
      return (
        <div className="space-y-4" data-testid="transactions-loading">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-6 bg-muted rounded w-1/4 mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      );
    }

    if (filteredTransactions.length === 0) {
      return (
        <div className="text-center py-16" data-testid="transactions-empty">
          <TrendingUp className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No transactions yet</h3>
          <p className="text-muted-foreground">Your transaction history will appear here once you start trading</p>
        </div>
      );
    }

    return (
      <div className="space-y-4" data-testid="transactions-list">
        {filteredTransactions.map((transaction) => (
          <Card key={transaction.id} className="border border-border" data-testid={`transaction-item-${transaction.id}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold" data-testid={`transaction-id-${transaction.id}`}>
                  Transaction #{transaction.id.slice(0, 8)}
                </h3>
                <Badge className={getStatusColor(transaction.status || 'pending')} data-testid={`transaction-status-${transaction.id}`}>
                  {transaction.status}
                </Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-muted-foreground">
                <div data-testid={`transaction-date-${transaction.id}`}>
                  <strong>Date:</strong> {formatDate(transaction.createdAt!.toString())}
                </div>
                <div data-testid={`transaction-amount-${transaction.id}`}>
                  <strong>Amount:</strong> {formatAmount(transaction.totalAmount)}
                </div>
                <div data-testid={`transaction-quantity-${transaction.id}`}>
                  <strong>Quantity:</strong> {transaction.quantity}
                </div>
                <div data-testid={`transaction-type-${transaction.id}`}>
                  <strong>Type:</strong> {transaction.type}
                </div>
              </div>
              {transaction.paymentMethod && (
                <div className="mt-4 text-sm" data-testid={`transaction-payment-${transaction.id}`}>
                  <strong>Payment Method:</strong> {transaction.paymentMethod}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8" data-testid="transactions-page">
      <h1 className="text-3xl font-bold mb-8" data-testid="page-title">Transactions</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} data-testid="transaction-tabs">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="sales" data-testid="tab-sales">Sales</TabsTrigger>
          <TabsTrigger value="barters" data-testid="tab-barters">Barters</TabsTrigger>
          <TabsTrigger value="donations" data-testid="tab-donations">Donations</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sales" data-testid="content-sales">
          {renderTransactionsList(filterTransactionsByType('sale'))}
        </TabsContent>
        
        <TabsContent value="barters" data-testid="content-barters">
          {renderTransactionsList(filterTransactionsByType('barter'))}
        </TabsContent>
        
        <TabsContent value="donations" data-testid="content-donations">
          {renderTransactionsList(filterTransactionsByType('donation'))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
