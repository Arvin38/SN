import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bot, MessageCircle, Send, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import type { Message, Conversation } from "@shared/schema";

interface ChatData {
  conversation: Conversation;
  messages: Message[];
}

export default function Chat() {
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: chatData, isLoading, error } = useQuery<ChatData>({
    queryKey: ["/api/chat/ai"],
    enabled: selectedChat === "ai",
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      return await apiRequest("POST", "/api/chat/ai/message", { message });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/ai"] });
      setMessageText("");
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatData?.messages]);

  const handleSendMessage = async () => {
    if (!messageText.trim()) return;
    sendMessageMutation.mutate(messageText);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (error && !isUnauthorizedError(error as Error)) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-8" data-testid="chat-error">
        <div className="text-center py-16">
          <p className="text-red-500">Failed to load chat. Please try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-8" data-testid="chat-page">
      <h1 className="text-3xl font-bold mb-8" data-testid="page-title">Chat</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-96">
        {/* Conversations List */}
        <Card data-testid="conversations-panel">
          <CardHeader>
            <CardTitle>Conversations</CardTitle>
          </CardHeader>
          <CardContent>
            {/* AI Assistant */}
            <div 
              onClick={() => setSelectedChat("ai")}
              className={`p-3 rounded-lg cursor-pointer hover:bg-muted mb-2 border border-border ${
                selectedChat === "ai" ? "bg-muted" : ""
              }`}
              data-testid="conversation-ai"
            >
              <div className="flex items-center">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-3">
                  <Bot className="text-white h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">SakaNect AI Assistant</div>
                  <div className="text-sm text-muted-foreground">Ask about crops and pricing</div>
                </div>
              </div>
            </div>
            
            {/* Empty state for other conversations */}
            <div className="text-center py-8" data-testid="conversations-empty">
              <MessageCircle className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No other conversations yet</p>
            </div>
          </CardContent>
        </Card>
        
        {/* Chat Interface */}
        <Card className="lg:col-span-2" data-testid="chat-interface">
          {selectedChat === "ai" ? (
            <>
              <CardHeader data-testid="chat-header">
                <CardTitle>SakaNect AI Assistant</CardTitle>
                <p className="text-sm text-muted-foreground">Get information about crops, pricing, and availability</p>
              </CardHeader>
              
              <CardContent className="h-64 overflow-y-auto p-4" data-testid="chat-messages">
                {isLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <>
                    {chatData?.messages.length === 0 && (
                      <div className="mb-4" data-testid="welcome-message">
                        <div className="flex items-start">
                          <Avatar className="mr-3">
                            <AvatarFallback className="bg-primary text-primary-foreground">
                              <Bot className="h-4 w-4" />
                            </AvatarFallback>
                          </Avatar>
                          <div className="bg-muted rounded-lg p-3 max-w-xs">
                            <p className="text-sm">
                              Hello! I'm the SakaNect AI Assistant. I can help you with information about crops, pricing, and availability. What would you like to know?
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {chatData?.messages.map((message) => (
                      <div key={message.id} className="mb-4" data-testid={`message-${message.id}`}>
                        {message.senderType === "ai" ? (
                          <div className="flex items-start">
                            <Avatar className="mr-3">
                              <AvatarFallback className="bg-primary text-primary-foreground">
                                <Bot className="h-4 w-4" />
                              </AvatarFallback>
                            </Avatar>
                            <div className="bg-muted rounded-lg p-3 max-w-xs">
                              <p className="text-sm">{message.content}</p>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-start justify-end">
                            <div className="bg-primary text-primary-foreground rounded-lg p-3 max-w-xs">
                              <p className="text-sm">{message.content}</p>
                            </div>
                            <Avatar className="ml-3">
                              <AvatarFallback>
                                <User className="h-4 w-4" />
                              </AvatarFallback>
                            </Avatar>
                          </div>
                        )}
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </>
                )}
              </CardContent>
              
              <div className="p-4 border-t border-border" data-testid="chat-input">
                <div className="flex space-x-2">
                  <Input 
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask about crops, pricing, or availability..." 
                    className="flex-1"
                    disabled={sendMessageMutation.isPending}
                    data-testid="input-message"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!messageText.trim() || sendMessageMutation.isPending}
                    data-testid="button-send-message"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full" data-testid="chat-default">
              <div className="text-center">
                <MessageCircle className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Select a conversation</h3>
                <p className="text-muted-foreground">Choose a conversation to start chatting</p>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
