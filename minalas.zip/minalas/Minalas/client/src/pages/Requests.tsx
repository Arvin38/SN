import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, ClipboardList } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import RequestModal from "@/components/RequestModal";
import type { CropRequest } from "@shared/schema";

export default function Requests() {
  const [showRequestModal, setShowRequestModal] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: requests = [], isLoading, error } = useQuery<CropRequest[]>({
    queryKey: ["/api/requests"],
  });

  if (error) {
    if (isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return null;
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'fulfilled':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8" data-testid="requests-page">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold" data-testid="page-title">My Requests</h1>
        <Button 
          onClick={() => setShowRequestModal(true)}
          className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-medium hover:opacity-90 transition-opacity"
          data-testid="button-new-request"
        >
          <Plus className="mr-2 h-4 w-4" />
          New Request
        </Button>
      </div>
      
      {/* Requests List */}
      {isLoading ? (
        <div className="space-y-4" data-testid="requests-loading">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-6 bg-muted rounded w-1/4 mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : requests.length === 0 ? (
        <div className="text-center py-16" data-testid="requests-empty">
          <ClipboardList className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <p className="text-muted-foreground">No requests found. Create your first request!</p>
        </div>
      ) : (
        <div className="space-y-4" data-testid="requests-list">
          {requests.map((request) => (
            <Card key={request.id} className="border border-border" data-testid={`request-item-${request.id}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold" data-testid={`request-name-${request.id}`}>
                    {request.cropName}
                  </h3>
                  <Badge className={getStatusColor(request.status || 'pending')} data-testid={`request-status-${request.id}`}>
                    {request.status}
                  </Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                  <div data-testid={`request-date-${request.id}`}>
                    <strong>Date:</strong> {formatDate(request.createdAt!.toString())}
                  </div>
                  <div data-testid={`request-quantity-${request.id}`}>
                    <strong>Quantity:</strong> {request.quantity || 'To be specified'}
                  </div>
                  <div data-testid={`request-budget-${request.id}`}>
                    <strong>Budget:</strong> {request.budget || 'To be specified'}
                  </div>
                </div>
                {request.notes && (
                  <div className="mt-4 text-sm" data-testid={`request-notes-${request.id}`}>
                    <strong>Notes:</strong> {request.notes}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <RequestModal 
        open={showRequestModal}
        onOpenChange={setShowRequestModal}
      />
    </div>
  );
}
