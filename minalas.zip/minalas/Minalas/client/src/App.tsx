import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Crops from "@/pages/Crops";
import Requests from "@/pages/Requests";
import Transactions from "@/pages/Transactions";
import Chat from "@/pages/Chat";
import CropListing from "@/pages/CropListing";
import Payments from "@/pages/Payments";
import Reports from "@/pages/Reports";
import Layout from "@/components/Layout";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  return (
    <Switch>
      {!isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <Layout>
          <Route path="/" component={Home} />
          <Route path="/crops" component={Crops} />
          <Route path="/requests" component={Requests} />
          <Route path="/transactions" component={Transactions} />
          <Route path="/chat" component={Chat} />
          <Route path="/crop-listing" component={CropListing} />
          <Route path="/payments" component={Payments} />
          <Route path="/reports" component={Reports} />
        </Layout>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
